package com.meetups.kuxu.meetup

val meetupModule = module